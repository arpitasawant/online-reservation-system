# Railway_Reservation_Java
Railway Reservation System using Java , JDBC and MySQL

Java-applets is used for the frontend 
MySQL which uses SQL database is used for backend
JDBC is used for establishing a connection between the frontend and backend
For detailed informartion refer the project documentation Railway Reservation System.pdf
SQL Scripts can be found in railway_reservation.sql and scripts_latest.sql

Application Screenshot
![alt text](https://raw.githubusercontent.com/hash84/Railway_Reservation_Java/master/s1.png)

SQL Schema
![alt_text](https://raw.githubusercontent.com/hash84/Railway_Reservation_Java/master/schema.png)

